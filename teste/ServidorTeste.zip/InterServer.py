from flask import Flask, render_template, request
import flask_cors 
import socket
setpoint_ant = "0" 
app = Flask(__name__)

#criar a primeira página do site

app.static_folder = 'static'


@app.route("/")
def home():
    return render_template("Conectar.html")
#@app.route("/Conectar", methods= ['GET','POST'])
@app.route("/Conectar", methods= ['GET','POST'])
def ConectarPagina():
    setpoint = request.form["Setpoint"]
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.connect(('192.168.1.67',8080))
    sock.send(setpoint.encode())
    from_server = sock.recv(4096)
    from_server = sock.recv(4096)
    aux = str(from_server).split("|")
    sock.close()
    
    return render_template("Conectar.html",tank1 = aux[1],tank2 = aux[3])

@app.route("/Conectar", methods= ['GET','POST'])
def Teste(Valores):
    
    return Valores

app.run(host='127.0.0.1',port=8000,debug=True)